import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style("whitegrid")

df = pd.read_csv("AmesHousing.csv")

print(df)

print("\nLast 5 Rows")
print(df.tail())

print("\nShape")
print(df.shape)

print("\nColumns")
print(df.columns)

print("\nData Types")
print(df.dtypes)

print("\nMissing Values")
print(df.isnull().sum())

print("\nDataset Information")
df.info()

print("\nStatistical Summary")
print(df.describe())

import matplotlib.pyplot as plt
import seaborn as sns

# Style
sns.set_style("whitegrid")

# 1. SalePrice Distribution
plt.figure(figsize=(8,5))
sns.histplot(df["SalePrice"], kde=True)
plt.title("SalePrice Distribution")
plt.show()

# 2. Correlation Heatmap
columns=["SalePrice", "Overall Qual", "Gr Liv Area", "Garage Cars", "Year Built"]
plt.figure(figsize=(15,10))
sns.heatmap(df[columns].corr(numeric_only=True), cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()

# 3. Overall Quality vs SalePrice
plt.figure(figsize=(8,5))
sns.boxplot(x="Overall Qual", y="SalePrice", data=df)
plt.title("Overall Quality vs SalePrice")
plt.show()

# 4. Gr Liv Area vs SalePrice
plt.figure(figsize=(8,5))
sns.scatterplot(x="Gr Liv Area", y="SalePrice", data=df)
plt.title("Ground Living Area vs SalePrice")
plt.show()


# 5. Overall Quality Count
plt.figure(figsize=(8,5))
sns.countplot(x="Overall Qual", data=df)
plt.title("Overall Quality Count")
plt.show()

# 6. Pair Plot
cols = ["SalePrice", "Overall Qual", "Gr Liv Area", "Garage Cars", "Year Built"]
sns.pairplot(df[cols])
plt.show()

from sklearn.model_selection import train_test_split
import pandas as pd

# Features and Target
X = df.drop("SalePrice", axis=1)
y = df["SalePrice"]

# Convert categorical columns to numerical
X = pd.get_dummies(X, drop_first=True)

# Fill missing values
X = X.fillna(X.mean())

# Split the data
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)

from sklearn.linear_model import LinearRegression
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Model
model = LinearRegression()

# Train
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Evaluation
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print("MAE:", mae)
print("MSE:", mse)
print("RMSE:", rmse)
print("R2 Score:", r2)

from sklearn.tree import DecisionTreeRegressor

# Model
dt_model = DecisionTreeRegressor(max_depth=8, random_state=42)

# Train
dt_model.fit(X_train, y_train)

# Predict
y_pred_dt = dt_model.predict(X_test)

# Evaluation
mae_dt = mean_absolute_error(y_test, y_pred_dt)
mse_dt = mean_squared_error(y_test, y_pred_dt)
rmse_dt = np.sqrt(mse_dt)
r2_dt = r2_score(y_test, y_pred_dt)

print("Decision Tree - MAE:", mae_dt)
print("Decision Tree - MSE:", mse_dt)
print("Decision Tree - RMSE:", rmse_dt)
print("Decision Tree - R2 Score:", r2_dt)

from sklearn.ensemble import RandomForestRegressor

# Model
rf_model = RandomForestRegressor(n_estimators=200, max_depth=10, random_state=42)

# Train
rf_model.fit(X_train, y_train)

# Predict
y_pred_rf = rf_model.predict(X_test)

# Evaluation
mae_rf = mean_absolute_error(y_test, y_pred_rf)
mse_rf = mean_squared_error(y_test, y_pred_rf)
rmse_rf = np.sqrt(mse_rf)
r2_rf = r2_score(y_test, y_pred_rf)

print("Random Forest - MAE:", mae_rf)
print("Random Forest - MSE:", mse_rf)
print("Random Forest - RMSE:", rmse_rf)
print("Random Forest - R2 Score:", r2_rf)


# Comparison Table
results = pd.DataFrame({
    "Model": ["Linear Regression", "Decision Tree", "Random Forest"],
    "MAE": [mae, mae_dt, mae_rf],
    "RMSE": [rmse, rmse_dt, rmse_rf],
    "R2 Score": [r2, r2_dt, r2_rf]
})

results = results.sort_values("R2 Score", ascending=False)
print(results.to_string(index=False))

